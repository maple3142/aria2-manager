# YAAW for Chrome

修改自 [YAAW2 for Chrome](https://chrome.google.com/webstore/detail/yaaw2-for-chrome/mpkodccbngfoacfalldjimigbofkhgjn) v1.2.3

## Refactored settings page

![Setting preview](https://i.imgur.com/oNkQijZ.png)
